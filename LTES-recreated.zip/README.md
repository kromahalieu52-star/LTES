# LTES — Logan Town Entertainment Spotlight

Static starter website for GitHub Pages.

## Files
- `index.html` — public website
- `admin.html` — admin dashboard preview
- `style.css` — site styling

## Publish
Upload these files to the root of the GitHub repository, then enable GitHub Pages from Settings → Pages → Deploy from branch → main → / (root).
